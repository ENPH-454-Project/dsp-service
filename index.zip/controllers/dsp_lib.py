from scipy.fftpack import fft, ifft
import numpy

class DspLib:
     def removeNoise(signal):
         fft_values = fft(signal)
         mean_value = numpy.mean(abs(fft_values))
         threshold = mean_value*5
         print(threshold)
         for i in range(len(fft_values)):
             #print(fft_values[i][0])
             if(abs(fft_values[i][0]) < threshold):
                 fft_values[i] = [0,0]
         return ifft(fft_values).real
